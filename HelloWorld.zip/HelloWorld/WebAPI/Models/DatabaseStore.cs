﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPI.Models
{
    public class DatabaseStore : Connection
    {
        private string server;
        private string database;
        private string userid;
        private string password;
        private string message;

        public string Server
        {
	       get { return server; }
           set { server = value; }
        }

        public string Database
        {
	       get { return database; }
           set { database = value; }
        }

        public string UserId
        {
	       get { return userid; }
           set { userid = value; }
        }

        public string Password
        {
	        get { return password; }
            set { password = value; }
        }

        public string Message
        {
            get { return message; }
            set { message = value; }
        }
        public void connectToStore()
        {
            //Connect to DB using property values 	        
        }
        public string storeMsg()
        {
 	        //Write a code to store the values into the DB
            return "Database Message";
        }

            
        
    }
}