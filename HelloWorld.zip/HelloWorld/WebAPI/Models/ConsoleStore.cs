﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPI.Models
{
    public class ConsoleStore : Connection
    {

        public string Server
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string Database
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string UserId
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string Password
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        private string message;
        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        public void connectToStore()
        {
            //Connect to DB using property values 
        }

        public string storeMsg()
        {
            //Write a code to store the values into the DB
            return "Console Message";
        }      
    }
}