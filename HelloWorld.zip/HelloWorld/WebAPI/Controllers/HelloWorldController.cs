﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Models;
using System.Net.Http.Formatting;
using System.Net;

namespace WebAPI.Controllers
{
    public class HelloWorldController : ApiController
    {
        //
        // GET: /HelloWorld/
        string storeType = System.Configuration.ConfigurationManager.AppSettings["StoreType"];

        [HttpGet]
        public string HelloWorldMsg()
        {
            return "Hello World";
        }

        [HttpPost]
        public IHttpActionResult SaveHelloWorldMsg(HelloWorldModel hwModel)
        {
            string msg = string.Empty;
            hwModel.storeType = storeType;
                       
            switch (hwModel.storeType)
            {                    
                case "Console":
                    ConsoleStore st = new ConsoleStore();
                    st.Message = hwModel.message;
                    msg = st.storeMsg();
                    break;

                case "Database":
                    DatabaseStore dt = new DatabaseStore();
                    dt.Message = hwModel.message;
                    msg = dt.storeMsg();
                    break;
            }

            return base.Content(HttpStatusCode.OK, new { Message = msg  }, new JsonMediaTypeFormatter(), "text/plain");
               
        }

    }
}
