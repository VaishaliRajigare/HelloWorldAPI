﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebAPI.Controllers;
using WebAPI.Models;

namespace WebAPI.Tests
{
    public class HelloWorldTest
    {
        [TestClass]
        public class HelloWorldTest
        {
            [TestMethod]
            public void GetHelloWorldMsg()
            {
                var controller = new HelloWorldController();

                string message = controller.HelloWorldMsg();

                Assert.IsNotNull(message);
                Assert.AreEqual(message, "Hello World");

            }

            [TestMethod]
            public void PostSaveHelloWorldMsg()
            {
                var returnMessage = string.Empty;
                var controller = new HelloWorldController();

                HelloWorldModel hwm = new HelloWorldModel();
                hwm.storeType = System.Configuration.ConfigurationManager.AppSettings["StoreType"];
                hwm.message = "Hello World";

                var response = controller.SaveHelloWorldMsg(hwm);
                string message = response.Content.ReadAsStringAsync().Result.ToString();

                Assert.IsNotNull(message);
                Assert.AreEqual("Console Message", returnMessage);

            }
        }
    }
}
