﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;


namespace Console
{
    class HelloWorldClient
    {        
        static void Main()
        {
            RunAsync().Wait();
        }

        static async Task RunAsync()
        {
            using (var hwClient = new HttpClient())
            {
                string apiResponse = string.Empty;
                hwClient.BaseAddress = new Uri("http://localhost:26825/");
                hwClient.DefaultRequestHeaders.Accept.Clear();
                
                // HTTP GET
                HttpResponseMessage getResponse = await hwClient.GetAsync("api/HelloWorld/HelloWorldMsg");
                if (getResponse.IsSuccessStatusCode)
                {
                    apiResponse = getResponse.Content.ReadAsStringAsync().Result.ToString();
                    System.Console.WriteLine(apiResponse);
                }
                               
                //HTTP POST
                //var PostHelloWord = new WebAPI.Models.HelloWorldModel() { message = "Hello World", storeType = "Database" };
                var PostHelloWord = new WebAPI.Models.HelloWorldModel() { message = "Hello World"};
                HttpResponseMessage postResponse = await hwClient.PostAsJsonAsync("api/HelloWorld/SaveHelloWorldMsg", PostHelloWord);
                if (postResponse.IsSuccessStatusCode)
                {
                    apiResponse = postResponse.Content.ReadAsStringAsync().Result.ToString();
                    System.Console.WriteLine(apiResponse);

                }

            }
        }

     }
}
